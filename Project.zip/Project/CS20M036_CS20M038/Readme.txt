There are three .ipynb files .
To run any file just upload the zip file named "Cranfield_Dataset" in the content folder of google collab.
Once its uploaded do run all.