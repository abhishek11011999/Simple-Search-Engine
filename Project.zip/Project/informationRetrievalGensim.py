# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 10:53:19 2022

@author: safik
"""

from heapq import merge
from util import *
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity,cosine_distances
from numpy import dot
from numpy.linalg import norm
import numpy as np
import gensim
from gensim import corpora
from gensim.models import LsiModel
from gensim.models.coherencemodel import CoherenceModel
from gensim.parsing.preprocessing import preprocess_documents

# Add your import statements here




class InformationRetrieval():

    def __init__(self):
        self.index = None
        self.tfidf = None
        self.dictionary = None
        self.lsi = None
    def buildIndex(self, docs, docIDs):
        """
        Builds the document index in terms of the document
        IDs and stores it in the 'index' class variable

        Parameters
        ----------
        arg1 : list
            A list of lists of lists where each sub-list is
            a document and each sub-sub-list is a sentence of the document
        arg2 : list
            A list of integers denoting IDs of the documents
        Returns
        -------
        None
        """

        index = None

        #Fill in code here

        #first merging the sentences in each doc to get one big list for each doc
        merged_docs = []
        for i in range(len(docs)):
            temp = []
            for j in docs[i]:
                temp.extend(j)
            merged_docs.append(temp)

        #converting the tokens into sentences for tfidf vectorizer
        final_corpus = []
        for i in range(len(merged_docs)):
            temp = " "
            final_corpus.append(temp.join(merged_docs[i]))
            
        processed_corpus = preprocess_documents(final_corpus)
        dictionary = gensim.corpora.Dictionary(processed_corpus)
        bow_corpus = [dictionary.doc2bow(text) for text in processed_corpus]
        
        tfidf = gensim.models.TfidfModel(bow_corpus, smartirs = 'npu')
        corpus_tfidf = tfidf[bow_corpus]
        
        
        lsi = LsiModel(corpus_tfidf, num_topics=280)
        index = gensim.similarities.MatrixSimilarity(lsi[corpus_tfidf])
        

        self.index = index
        self.dictionary = dictionary
        self.lsi = lsi
        self.tfidf = tfidf
        

    def rank(self, queries):
        """
        Rank the documents according to relevance for each query

        Parameters
        ----------
        arg1 : list
            A list of lists of lists where each sub-list is a query and
            each sub-sub-list is a sentence of the query
        

        Returns
        -------
        list
            A list of lists of integers where the ith sub-list is a list of IDs
            of documents in their predicted order of relevance to the ith query
        """

        doc_IDs_ordered = []

        #Fill in code here
        #first merging the sentences in each doc to get one big list for each doc
        merged_queries = []
        for i in range(len(queries)):
            temp = []
            for j in queries[i]:
                temp.extend(j)
            merged_queries.append(temp)

        #converting the tokens into sentences for tfidf vectorizer
        final_queries = []
        for i in range(len(merged_queries)):
            temp = " "
            final_queries.append(temp.join(merged_queries[i]))

        

        for i in range(len(final_queries)):
            #here i refers to the query
            #i.e., we are iterating over each query.
            
            new_doc = gensim.parsing.preprocessing.preprocess_string(final_queries[i])
            new_vec = self.dictionary.doc2bow(new_doc)
            vec_bow_tfidf = self.tfidf[new_vec]
            vec_lsi = self.lsi[vec_bow_tfidf]
            
            sims = self.index[vec_lsi]
            
            doc_order = []
            for s in sorted(enumerate(sims), key=lambda item: -item[1])[:10]:
                doc_order.append(s[0])
                #print(f”{df[‘Title’].iloc[s[0]]} : {str(s[1])}”)
            
            
            doc_IDs_ordered.append(doc_order)
            
        print(doc_IDs_ordered)
    
        return doc_IDs_ordered



